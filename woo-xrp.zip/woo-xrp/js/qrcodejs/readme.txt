See https://github.com/davidshimjs/qrcodejs
